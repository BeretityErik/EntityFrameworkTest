﻿using EFMVC.Models;
using Microsoft.EntityFrameworkCore;

namespace EFMVC.Context
{
    public class MVCcontext :DbContext
    {
        public MVCcontext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Ora> Orak { get; set; }

        public DbSet<Tanar> Tanarok { get; set; }
        
    }
}