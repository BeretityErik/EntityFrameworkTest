﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EFMVC.Migrations
{
    public partial class ManyToOne : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OraTanar");

            migrationBuilder.AddColumn<int>(
                name: "SubjectId",
                table: "Tanar",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Tanar_SubjectId",
                table: "Tanar",
                column: "SubjectId");

            migrationBuilder.AddForeignKey(
                name: "FK_Tanar_Ora_SubjectId",
                table: "Tanar",
                column: "SubjectId",
                principalTable: "Ora",
                principalColumn: "SubjectId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tanar_Ora_SubjectId",
                table: "Tanar");

            migrationBuilder.DropIndex(
                name: "IX_Tanar_SubjectId",
                table: "Tanar");

            migrationBuilder.DropColumn(
                name: "SubjectId",
                table: "Tanar");

            migrationBuilder.CreateTable(
                name: "OraTanar",
                columns: table => new
                {
                    SubjectTeachersTeacherId = table.Column<int>(type: "int", nullable: false),
                    TeacherSubjectSubjectId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OraTanar", x => new { x.SubjectTeachersTeacherId, x.TeacherSubjectSubjectId });
                    table.ForeignKey(
                        name: "FK_OraTanar_Ora_TeacherSubjectSubjectId",
                        column: x => x.TeacherSubjectSubjectId,
                        principalTable: "Ora",
                        principalColumn: "SubjectId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OraTanar_Tanar_SubjectTeachersTeacherId",
                        column: x => x.SubjectTeachersTeacherId,
                        principalTable: "Tanar",
                        principalColumn: "TeacherId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OraTanar_TeacherSubjectSubjectId",
                table: "OraTanar",
                column: "TeacherSubjectSubjectId");
        }
    }
}
