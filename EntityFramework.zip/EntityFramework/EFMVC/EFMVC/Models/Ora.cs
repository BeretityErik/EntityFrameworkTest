﻿namespace EFMVC.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


public class Ora
{
    [Key]
    
    public int SubjectId { get; set; }

    public string? SubjectName { get; set; }    

    public string SubjectTerm { get; set; } 

    public int SubjectCredets { get; set; }
    public List<Tanar> SubjectTeachers { get; set; } = new List<Tanar>();
}
