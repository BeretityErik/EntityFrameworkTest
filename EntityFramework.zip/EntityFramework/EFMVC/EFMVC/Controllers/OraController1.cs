﻿using EFMVC.Context;
using EFMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace EFMVC.Controllers
{
    public class OraController1 : Controller
    {
        MVCcontext db;
        public OraController1(MVCcontext _db)
        {
            db = _db;
        }

        public IActionResult Index()
        {
            IEnumerable<Ora> orak = db.Orak.Select(s => s).ToList();
            return View(orak);
        }
    }
}
