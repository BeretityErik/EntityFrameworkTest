﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace A17.Models
{
    [Serializable]
    public class Kerdes
    {
        private int sorszam;
        private string kerdesszoveg;
        [XmlElement("Valasz")]
        public List<string> Valasz;
        private string megoldas;

        public Kerdes()
        {
            Valasz = new List<string>();
        }
        public int Sorszam
        {
            get
            {
                return sorszam;
            }

            set
            {
                sorszam = value;
            }
        }

        public string Kerdesszoveg
        {
            get
            {
                return kerdesszoveg;
            }

            set
            {
                kerdesszoveg = value;
            }
        }

        public string Megoldas
        {
            get
            {
                return megoldas;
            }

            set
            {
                megoldas = value;
            }
        }
    }

    
    
    
}