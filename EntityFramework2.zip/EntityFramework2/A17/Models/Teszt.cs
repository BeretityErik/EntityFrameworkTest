﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace A17.Models
{
    [Serializable]
    public class Teszt
    {
        [XmlElement("Kerdes")]
        public List<Kerdes> kerdeslista = new List<Kerdes>();

    }
}