﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using A17.Models;

namespace A17.Controllers
{
    public class megoldasController : Controller
    {
        // GET: megoldas
        public ActionResult Index(List<string> Megoldas)
        {
            //a tesztelescontroller-bol megkapjuk, hogy melyik kerdeseket jelenitettuk meg:
            ViewBag.kerdeslista = TempData["kerdeslista"];
            if (Megoldas != null && ViewBag.kerdeslista!=null)
            {
                ViewBag.valaszlista = Megoldas;
                return View();

            }
            return Content("Nem töltötte ki az űrlapot!");
        }
    }
}