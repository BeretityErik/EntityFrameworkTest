﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using A17.Models;

namespace A17.Controllers
{
    public class tesztelesController : kiolvasasController
    {
        private List<Kerdes> megjelenitettKerdesek()
        {
            var rand = new Random();
            Teszt tesztszovege = xmlKiolvasas();
            List<Kerdes> kerdeslista = tesztszovege.kerdeslista.OrderBy(x => rand.Next()).Take(5).ToList();
            return kerdeslista;
        }
        // GET: teszteles
        public ActionResult Index()
        {     
            ViewBag.kerdeslista = megjelenitettKerdesek();
            //a megoldascontroller-be elkuldjuk, hogy melyik kerdeseket jelenitettuk meg:
            TempData["kerdeslista"] = ViewBag.kerdeslista;
            return View();
        }

        [HttpPost]
        public ActionResult Index(List<string> Megoldas)
        {
            return RedirectToAction("Index", "megoldas");
        }
    }
}