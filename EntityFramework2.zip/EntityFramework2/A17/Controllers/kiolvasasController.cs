﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Serialization;
using A17.Models;
using System.IO;

namespace A17.Controllers
{
    public class kiolvasasController : Controller
    {
        // GET: kiolvasas
        public Teszt xmlKiolvasas()
        {
            XmlSerializer deserializer = new XmlSerializer(typeof(Teszt));
            TextReader reader = new StreamReader(Server.MapPath("~/App_Data/test.xml"));
            object obj = deserializer.Deserialize(reader);
            Teszt XmlData = (Teszt)obj;
            reader.Close();
            return XmlData;
        }
    }
}